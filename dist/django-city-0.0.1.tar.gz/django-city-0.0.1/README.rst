Django-city
=======================

一个基于django的城市模块

快速开始:
---------

安装django-city:

.. code-block::

    pip install django-city

修改setttings.py:

.. code-block::

    INSTALLED_APPS = (
        ...
        'city',
        ...
    )


版本更改:
---------

v0.0.1 第一版
